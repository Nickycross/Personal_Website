//ROWS
var elements = document.getElementsByClassName("row1");
var elements = document.getElementsByClassName("row2");
var elements = document.getElementsByClassName("row3");