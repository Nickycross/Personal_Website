# my_own_portfolio
This is my first project and the project that is going to push me to learn to code and start persuing my dream career!
